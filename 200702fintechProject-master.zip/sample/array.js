var car1 = "Saab";
var car2 = "Volvo";
var car3 = "BMW";

var cars = ["Saab", "Volvo", "BMW"];

//in java
// public int[] numList = new Array[5];
// arrayList alist = new ArrayList();

var array = [car1, car2, car3];

console.log(cars);
console.log(cars[0]);
console.log(cars[1]);
console.log(cars[2]);

console.log(cars.length);

console.log(array);
