//public String name = "gwanwoo you";
//private int age = 32; float, double

var length = 16; // Number
var lastName = "Johnson"; // String

var flaotType = 0.11;

var obj = { firstName: "John", lastName: "Doe" }; // Object

var x = 16 + "Volvo";
console.log(x);
var y = "16" + "Volvo";
console.log(y);
var z = 16 + "Volvo";
console.log(z);
var a = "Volvo" + 16;
console.log(a);
var b = 16 + 4 + "Volvo";
console.log(b);

console.log(obj, flaotType);
