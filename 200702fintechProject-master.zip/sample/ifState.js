var hour = 20;
var greeting = "hello";

if (hour < 18) {
  greeting = "Good day";
}

console.log(greeting);
