var x = 5; // assign the value 5 to x
var y = 2; // assign the value 2 to y
var z = x + y; // assign the value 7 to z (x + y)
var a = x - y;
var b = x * y;
var c = x / y;

console.log("x: " + x);
console.log("y: " + y);
console.log("z: " + z);
console.log("a: " + a);
console.log("b: " + b);
console.log("c: " + c);
